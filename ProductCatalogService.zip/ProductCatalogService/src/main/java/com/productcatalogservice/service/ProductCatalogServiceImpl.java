package com.productcatalogservice.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.productcatalogservice.model.ProductCatalog;
import com.productcatalogservice.repository.ProductRepository;

@Service
public class ProductCatalogServiceImpl implements ProductCatalogService {
	
	@Autowired
	ProductRepository productRepository;
	
	@Override
	public ProductCatalog createProduct(ProductCatalog product) {
		try {
			ProductCatalog prd = productRepository.save(product);
			return prd;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public ProductCatalog updateProduct(ProductCatalog product) {

		try {
			//productRepository.findById(id);
			ProductCatalog prd = productRepository.save(product);
			return prd;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public String deleteProduct(int id) {
		try {
			productRepository.deleteById(id);
			return "success";
		} catch (Exception e) {
			e.printStackTrace();
			return "fail";
		}

	}

	@Override
	public Optional<ProductCatalog> getProductById(int id) {
		Optional<ProductCatalog> prd = null;
		try {
			prd = productRepository.findById(id);
			return prd;
		} catch (Exception e) {
			e.printStackTrace();
			return Optional.empty();
		}
	}

	@Override
	public Optional<List<ProductCatalog>> getProducts() {
		Optional<List<ProductCatalog>> prd = null;
		try {
			prd = Optional.ofNullable(productRepository.findAll());
			return prd;
		} catch (Exception e) {
			e.printStackTrace();
			return Optional.empty();
		}
	}

	@Override
	public Optional<List<ProductCatalog>> getProductsByCategory(String categoryName) {
		return Optional.ofNullable(productRepository.findByCategory(categoryName));

	}

}
