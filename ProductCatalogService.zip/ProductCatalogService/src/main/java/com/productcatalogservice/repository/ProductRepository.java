package com.productcatalogservice.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.data.jpa.repository.Modifying;
//import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.productcatalogservice.model.ProductCatalog;

@Repository
public interface ProductRepository extends JpaRepository<ProductCatalog, Integer> {
	
//	@Modifying
//	@Query("update product_catalog p set p.category = ?1, p.description = ?2, p.expirydate = ?3, p.productname = ?4 where p.product_id = ?5")
//	public ProductCatalog updateProduct(ProductCatalog product);
	public List<ProductCatalog> findByCategory(String category);
}
