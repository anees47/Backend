package com.tcs.restapi.review.controller;

import com.tcs.restapi.review.exception.ResourceNotFoundException;
import com.tcs.restapi.review.model.Review;
import com.tcs.restapi.review.repository.ReviewRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api")
public class ReviewController {

    @Autowired
    ReviewRepository reviewRepository;

    //finding all reviews
    @GetMapping("/review")
    public List<Review> getAllReviews() {
        return reviewRepository.findAll();
    }
    //creating a review
    @PostMapping("/review")
    public Review createReviews(@Valid @RequestBody Review review) {
        return reviewRepository.save(review);
    }

    

    //updating a review by reviewId
    @PutMapping("/review/{reviewId}")
    public Review updateReview(@PathVariable(value = "reviewId") Long reviewId,
                                           @Valid @RequestBody Review reviewDetails) {

    	Review review = reviewRepository.findById(reviewId)
                .orElseThrow(() -> new ResourceNotFoundException("Review", "reviewId", reviewId));

    	review.setComment(reviewDetails.getComment());
    	review.setUserName(reviewDetails.getUserName());
    	review.setRating(reviewDetails.getRating());

        Review updatedNote = reviewRepository.save(review);
        return updatedNote;
    }

    //deleting a review by reviewId
    @DeleteMapping("/review/{reviewId}")
    public ResponseEntity<?> deleteReview(@PathVariable(value = "reviewId") Long reviewId) {
    	Review review = reviewRepository.findById(reviewId)
                .orElseThrow(() -> new ResourceNotFoundException("Review", "reviewId", reviewId));

    	reviewRepository.delete(review);

        return ResponseEntity.ok().build();
    }
    
  //getting a review by productId
    @GetMapping("/review/{productId}")
    public Review getProductById(@PathVariable(value = "productId") Long productId) {
        return reviewRepository.findById(productId)
                .orElseThrow(() -> new ResourceNotFoundException("Review", "productId", productId));
    }
    
    @GetMapping("/review/productId/{productId}")
    public Review getProductByProductId(@PathVariable(value = "productId") Long productId) {
        return reviewRepository.findByProductId(productId);
                
    }
    
    
    
    
    
   
}
