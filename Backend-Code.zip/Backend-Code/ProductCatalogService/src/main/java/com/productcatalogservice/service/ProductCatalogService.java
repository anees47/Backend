package com.productcatalogservice.service;

import java.util.List;
import java.util.Optional;

import com.productcatalogservice.model.ProductCatalog;

public interface ProductCatalogService {
	
	public ProductCatalog createProduct(ProductCatalog product);
	public ProductCatalog updateProduct(ProductCatalog product);
	public String deleteProduct(int id);
	public Optional<ProductCatalog> getProductById(int id);
	public Optional<List<ProductCatalog>> getProducts();
	public Optional<List<ProductCatalog>> getProductsByCategory(String categoryName);
}
