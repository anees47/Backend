package com.productcatalogservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.productcatalogservice.model.ProductCatalog;
import com.productcatalogservice.service.ProductCatalogService;
@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/productcatalog")
public class ProductCatalogController {
	
	@Autowired
	ProductCatalogService productCatalogService;
	
	@PostMapping("/create")
	public ProductCatalog createEmployee(@RequestBody ProductCatalog product)
	{	
		return productCatalogService.createProduct(product);
	}
	
	@PutMapping("/update")
	public ProductCatalog updateEmployee(@RequestBody ProductCatalog product)
	{
		productCatalogService.updateProduct(product);
		return product;
	}
	
	@GetMapping("/productlist")
	public List<ProductCatalog> getProducts() {
		return productCatalogService.getProducts().get();
	}
	
	@GetMapping("/{id}")
	public ProductCatalog getProductById(@PathVariable("id") int id)
	{
		return productCatalogService.getProductById(id).get();
	}
	
	@GetMapping("/category={category}")
	public List<ProductCatalog> getProductsByCategory(@PathVariable String category)
	{
		return productCatalogService.getProductsByCategory(category).get();
	}
	
	@DeleteMapping("/{id}")
	public String deleteProduct(@PathVariable("id") int id)
	{
		productCatalogService.deleteProduct(id);
		return "success";
	}
}
