package com.stockservice.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.stockservice.model.Stock;

@Repository
public interface StockRepository extends JpaRepository<Stock, Integer> {
	
	public Optional<Stock> findByProductId(int productId);
	public Stock deleteById(int productId);

}
