package com.stockservice.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stockservice.model.Stock;
import com.stockservice.repository.StockRepository;

@Service
public class StockServiceImpl implements StockService {
	
	@Autowired
	StockRepository stockRepository;
	
	@Override
	public Stock createStock(Stock stock) {
		try {
			Optional<Stock> stk = stockRepository.findByProductId(stock.getProductId());

			if(stk.isPresent()) {
				return null;
			}else {
				return stockRepository.save(stock);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
	@Override
	public Stock updateStock(Stock stock) {
		try {
			Optional<Stock> stk = stockRepository.findByProductId(stock.getProductId());

			stk.ifPresent(abc ->{
				stock.setStockId(abc.getStockId());
			});
			
			if(stk.isPresent()) {
				return stockRepository.save(stock);
			}else {
				return null;
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public String deleteStock(int id) {
		try {
			Optional<Stock> stk = stockRepository.findByProductId(id);
			stk.ifPresent(abc ->{
				stockRepository.deleteById(abc.getStockId());
			});
			if(stk.isPresent()) {
				return "success";
			}else {
				return "product is not available";
			}
		} catch (Exception e) {
			e.printStackTrace();
			return "fail";
		}
	}

	@Override
	public Optional<Stock> getById(int id) {
		try {
			Optional<Stock> stk = stockRepository.findByProductId(id);
			stk.ifPresent(abc ->{
				stockRepository.findById(abc.getStockId());
			});
			if(stk.isPresent()) {
				return stk;
			}else {
				return null;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return Optional.empty();
		}
	}

	@Override
	public Optional<List<Stock>> getAll() {
		Optional<List<Stock>> stk = null;
		try {
			stk = Optional.ofNullable(stockRepository.findAll());
			return stk;
		} catch (Exception e) {
			e.printStackTrace();
			return Optional.empty();
		}
	}

}
