package com.tcs.pricerestapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PriceRestApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(PriceRestApiApplication.class, args);
	}

}
