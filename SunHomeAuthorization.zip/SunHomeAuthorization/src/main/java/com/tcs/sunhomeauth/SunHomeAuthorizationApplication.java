package com.tcs.sunhomeauth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SunHomeAuthorizationApplication {

	public static void main(String[] args) {
		SpringApplication.run(SunHomeAuthorizationApplication.class, args);
	}

}
