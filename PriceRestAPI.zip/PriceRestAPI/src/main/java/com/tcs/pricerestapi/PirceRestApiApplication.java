package com.tcs.pricerestapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PirceRestApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(PirceRestApiApplication.class, args);
	}

}
