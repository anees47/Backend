package com.tcs.pricerestapi.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tcs.pricerestapi.exception.ResourceNotFoundException;
import com.tcs.pricerestapi.model.Price;
import com.tcs.pricerestapi.repository.PriceRepository;



@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api")
public class PriceController {

    @Autowired
    PriceRepository priceRepository;

    //finding all prices
    @GetMapping("/price")
    public List<Price> getAllprices() {
        return priceRepository.findAll();
    }
    //creating a price
    @PostMapping("/price")
    public Price createPrice(@Valid @RequestBody Price price) {
        return priceRepository.save(price);
    }
    
    @GetMapping("/productId/{id}")
	public Price getById(@PathVariable("id") int id)
	{
		return priceRepository.findByProductId(id);
	}

    //getting a price by priceId
    @GetMapping("/price/{priceId}")
    public Price getpriceById(@PathVariable(value = "priceId") int priceId) {
        return priceRepository.findById(priceId)
                .orElseThrow(() -> new ResourceNotFoundException("Price", "priceId", priceId));
    }

    //updating a price by priceId
    @PutMapping("/price/{priceId}")
    public Price updateprice(@PathVariable(value = "priceId") int priceId,
                                           @Valid @RequestBody Price priceDetails) {

    	Price price = priceRepository.findById(priceId)
                .orElseThrow(() -> new ResourceNotFoundException("Price", "priceId", priceId));

    	price.setPriceValue(priceDetails.getPriceValue());
    	

    	Price updatedNote = priceRepository.save(price);
        return updatedNote;
    }

    //deleting a price by priceId
    @DeleteMapping("/{priceId}")
    public ResponseEntity<?> deleteprice(@PathVariable(value = "priceId") int priceId) {
    	Price price = priceRepository.findById(priceId)
                .orElseThrow(() -> new ResourceNotFoundException("Price", "priceId", priceId));

    	priceRepository.delete(price);

        return ResponseEntity.ok().build();
    }
}

