package com.stockservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.stockservice.model.Stock;
import com.stockservice.service.StockService;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/stock")
public class StockController {
	
	@Autowired
	StockService stockService;
	
	@PostMapping("/create")
	public Stock createStock(@RequestBody Stock stock)
	{	
		return stockService.createStock(stock);
	}
	
	@PutMapping("/update")
	public Stock updateStock(@RequestBody Stock stock)
	{
		return stockService.updateStock(stock);
	}
	
	@GetMapping("/stocklist")
	public List<Stock> getAll() {
		return stockService.getAll().get();
	}
	
	@GetMapping("/productId/{id}")
	public Stock getById(@PathVariable("id") int id)
	{
		return stockService.getById(id).get();
	}
	
	@DeleteMapping("/{id}")
	public String deleteStock(@PathVariable("id") int id)
	{
		stockService.deleteStock(id);
		return "success";
	}

}
