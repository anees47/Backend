package com.stockservice.service;

import java.util.List;
import java.util.Optional;

import com.stockservice.model.Stock;

public interface StockService {
	
	public Stock createStock(Stock stock);
	public Stock updateStock(Stock stock);
	public String deleteStock(int id);
	public Optional<Stock> getById(int id);
	public Optional<List<Stock>> getAll();
}
